global initial_flag;

ng_A=[1,1,1,2,2,1,1,1,1,1,1,2,3,1,1,1,1,2,2,2,2,3,1,1,1,1,2,2];
nh_A=[1,1,1,1,1,6,2,2,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1];

for f=1:28
    initial_flag = 0;
    x = load("check_F"+string(f)+"_D30_.txt");
    x2 = x(:,1:30);
    f22 = x(:,40);
    [f2,g2,h2] = CEC2017(x2,f);
    dif = abs(f22 - f2) > 1e-2;
    res = sum(dif);
    for i=1:ng_A(f)
        dif = abs(x(:,30+i) - g2(:,i)) > 1e-2;
        res = res + sum(dif);
    end
    for i=1:nh_A(f)
        dif = abs(x(:,33+i) - h2(:,i)) > 1e-2;
        res = res + sum(dif);
    end
    [f,res]
end